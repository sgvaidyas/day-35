﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Collections.Generic;

namespace Gamedesign
{
    public partial class Gamepanel : Form
    {
        //to store the object
        public Playersinfo p;
        public Dictionary<string, string> btnprop;
        public int flag;
        public int moves;
        public List<string> colors;
        public Gamepanel()
        {
            InitializeComponent();

        }
        //create a parameterized constructor
        public Gamepanel(Playersinfo ob)
        {
            InitializeComponent();
            btnprop = new Dictionary<string, string>();

            colors = new List<string>();
            colors.Add("red");
            colors.Add("green");
            p = ob;
            flag = 0;
            moves = 1;
        }


        private void Gamepanel_Load(object sender, EventArgs e)
        {
            lblPlayer1.Text = p.player1;
            lblPlayer2.Text = p.player2;
            gameplan();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void gameplan()
        {
            if (moves <= 9 && flag == 0)
            {
                if (moves % 2 == 1)
                {
                    lblmoves.Text = "PLAYER 1 MAKE THE MOVE";
                    p.p1 = 1;
                    p.p2 = 0;
                }
                else
                {
                    lblmoves.Text = "PLAYER 2 MAKE THE MOVE";
                    p.p1 = 0;
                    p.p2 = 1;
                }
                moves++;
                if (moves >= 5)
                    flag = checkwinner();

                if(flag==1)
                    MessageBox.Show("Player 1 is winner");
                else if(flag==2)
                    MessageBox.Show("Player 2 is winner");
            }
            if(moves>10)
                MessageBox.Show("Match draw");
        }

        private void button_Click(object sender, EventArgs eventArgs)
        {
            //MessageBox.Show(((Button)sender).Name);
            Button b = (Button)sender;
            if (p.p1 == 1 && b.BackColor == Color.Black)
            {
                b.BackColor = Color.Red;
                btnprop.Add(b.Name,"red");
                gameplan();
            }
            else if (p.p2 == 1 && b.BackColor == Color.Black)
            {
                b.BackColor = Color.Green;
                btnprop.Add(b.Name, "green");
                gameplan();
            }
            else
                MessageBox.Show("Please chose other button");
        }
        int functionbuttoncheck(string b1,string b2,string b3,string color)
        {
            if (btnprop.ContainsKey(b1) && btnprop.ContainsKey(b2) && btnprop.ContainsKey(b3))
            {
                if (btnprop[b1] == color && btnprop[b2] == color && btnprop[b3] == color)
                    return 1;
            }
            return 0;
        }

        int checkwinner()
        {
            string color;
            int i;
            for(i=0;i<colors.Count;i++)
            {
                color = colors[i];
                if (functionbuttoncheck("button1", "button2", "button3", color) ==1)
                    break;
                if (functionbuttoncheck("button4", "button5", "button6", color) == 1)
                    break;
                if (functionbuttoncheck("button7", "button8", "button9", color) == 1)
                    break;
                if (functionbuttoncheck("button1", "button4", "button7", color) == 1)
                    break;
                if (functionbuttoncheck("button2", "button5", "button8", color) == 1)
                    break;
                if (functionbuttoncheck("button3", "button6", "button9", color) == 1)
                    break;
                if (functionbuttoncheck("button1", "button5", "button9", color) == 1)
                    break;
                if (functionbuttoncheck("button3", "button5", "button7", color) == 1)
                    break;
            }
            if (i == 0)
                return 1;
            else if (i == 1)
                return 2;
            else
                return 0;
        }

    }
}
