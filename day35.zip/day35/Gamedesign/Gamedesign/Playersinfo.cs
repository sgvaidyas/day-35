﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gamedesign
{
    public class Playersinfo
    {
        public string player1, player2;
        public int p1, p2;

        public Playersinfo()
        {
            p1 = 0;
            p2 = 0;
        }

    }
}
