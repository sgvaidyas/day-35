﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gamedesign
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            Playersinfo ob = new Playersinfo();
            ob.player1 = txtPlayer1.Text;
            ob.player2 = txtPlayer2.Text;

            MessageBox.Show("Welcome "+ ob.player1+" & "+  ob.player2);           
            Gamepanel gp = new Gamepanel(ob);
            gp.Show();
        }
    }
}
